import React, { useEffect,useState } from 'react'
import Content from './Content';
import ImageView from './ImageView';
// import Data from '../Json/data.json';
import Axios from 'axios';

import '../App.css'

const Card = () => {

    const [Data, setData] = useState([]);

    useEffect(() => {
        Axios.get('http://localhost:3002/frank').then((res) => {
            setData(res.data)
        })
    });
    
    return (
        <>
            {
                Data.map((val) => (
                    // <div className="conrainer">
                    //     <div className="card-block">
                    //         <div className="card-body" style={{ width: 18 + "rem", display: "grid", gridColumn: "1fr 1fr 1fr" }}>
                    <div className="card">
                        <ImageView imgdata={val.imagecolor} cat={val.cat} />
                        <Content contentdata={val} />
                    </div>


                ))
            }

        </>
    );
}
export default Card;