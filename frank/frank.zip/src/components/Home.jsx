import React from 'react'

const Home = () => {
    return (
        <div>
          <h1>hello</h1>  
        </div>
    )
}

export default Home
