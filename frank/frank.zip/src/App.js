import Card from './components/Card';
// import Data from './Json/data.json';
import ImageView from './components/ImageView';
import Content from './components/Content';
import { useEffect, useState } from 'react';

import Axios from 'axios';
// // import { Card } from 'react-bootstrap';
import './App.css';
// import { BrowserRouter, Route } from "react-router-dom";

import { BrowserRouter as Router, Routes, Route,Navigate } from "react-router-dom";
import Home from './components/Home';

function App() {

  return (
    // <BrowserRouter>
    //   <div className="main">
    //     <Route path="/" exact>
    //       <h1>hello</h1>
    //     </Route>
    //     <Route path="/card" component={Card} />
    //   </div>
    // </BrowserRouter>
    // <Router>
    //   <Route exact path="/">
    //     <Card/>
    //   </Route>
    // </Router>
    <Router>
      {/* <Navigate to="/" replace="/card" /> */}
      <div className="main">
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/card' element={<Card />} />
        </Routes>
      </div>
    </Router>

  );
}

const home = ()=>{
  return(
    <div>
      <h1>hello</h1>
    </div>
  )
}

// const App = () => {
//   const renderCard = (card, index) => {
//     console.log(card);
//     return (
//       <Card style={{ width: "200px" }} key={index} className="box">
//         <Card.Img variant="top" src={card.image} />
//         <Card.Body>
//         <Card.Img variant="top" src={card.img} className="simage" />{'\u2022'} {card.name}
//           <Card.Text></Card.Text>
//           <Card.Text>{card.date}</Card.Text>
//           <Card.Text>{card.dis}</Card.Text>
//           <Card.Text>{card.time}</Card.Text>
//           <Card.Text>{card.views}</Card.Text>
//         </Card.Body>
//       </Card>
//     );
//   };
//   return <div className="grid">{Data.map(renderCard)}</div>;
// }

export default App;
