import './App.css';
import Covid from './components/Covid';

function App() {
  return (
    <div className="App">
      <Covid/>
    </div>
  );
}

export default App;
