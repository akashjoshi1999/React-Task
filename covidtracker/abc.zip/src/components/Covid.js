import React from 'react'
import { useEffect, useState } from 'react';
import './covid.css';

const Covid = () => {

    const [data, setData] = useState([])
    const [states, setStates] = useState([]);
    const [countries, setCountries] = useState([]);
    const [countryList, SetCountryList] = useState([]);
    const [countriesName, setCountriesName] = useState("India");
    var countryLen;
    const getCovidData = async () => {
        fetch("https://disease.sh/v3/covid-19/countries")
            .then((response) => response.json())
            .then((data) => {
                const countries = data.map((country) => ({
                    name: country.country,
                    value: country.countryInfo.iso2,
                }));
                countryLen = data.length;
                for (let i = 0; i < countryLen; i++) {
                    countryList.push(countries[i].name);
                }
                setCountries(countries);
            });
        
    }


    useEffect(() => {
        getCovidData();
    }, [])

    const onShowDetails = (e) => {
        // console.log("af",e.target);  
        // setCountriesName(e.target.value);
        // console.log("name",countriesName);
    }

    const onShow = (e) =>{
        console.log("caca",e.target);
    }

    return (
        <>
            <h2>🔴 LIVE</h2>
            <h1>COVID-19 CORONAVIRUS TRACKER</h1>
            <label for="Country">Select The Country:</label>
            {/* <select id="Country" name="Country" value={countriesName} onChange={onShowDetails}>
                
                {countryList.map(list => {
                    
                    return (
                        <option value={list}> {list} </option>
                    )
                })}
            </select> */}
            <select onChange={onShowDetails} value={countriesName}>
                {
                    countryList.map(key => (
                        <option value={key} >{key}</option>

                    ))
                }
            </select>
            <button onClick={onShow}>submit</button>
            <div className='row'>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>OUR</span> COUNTRY</p>
                        <p className='card_value'>INDIA</p>
                    </div>
                </div>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>TOTAL</span> RECOVERED</p>
                        <p className='card_value'>{data.recovered}</p>
                    </div>
                </div>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>TOTAL</span> CONFIRMED</p>
                        <p className='card_value'>{data.confirmed}</p>
                    </div>
                </div>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>TOTAL</span> DEATHS</p>
                        <p className='card_value'>{data.deaths}</p>
                    </div>
                </div>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>TOTAL</span> ACTIVE</p>
                        <p className='card_value'>{data.active}</p>
                    </div>
                </div>
                <div className='column'>
                    <div className='card'>
                        <p className='card_name'><span>TOTAL</span> UPDATED</p>
                        <p className='card_value'>{data.lastupdatedtime}</p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Covid
